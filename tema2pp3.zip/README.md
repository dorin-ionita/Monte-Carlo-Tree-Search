# Monte-Carlo-Tree-Search
A Monte Carlo Tree Search implemented in Haskell. A version specialised for game use.
